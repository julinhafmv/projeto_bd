<?php
 echo ("Olá,Mundo!<br>");
 echo "Boa tarde!<br>";
 echo "Boa", "Tarde<br>";
 echo "Boa"."Tarde<br>";

$a = "ola";
$b = 10;
$c = 1.5;
$d = true;

echo $a. "<br>";
echo $b. "<br>";
echo $c. "<br>";
echo $d. "<br>";

var_dump($d); 
var_dump($a);
var_dump($b);
var_dump($c);


?>

